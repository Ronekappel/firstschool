<nav class="main-nav w-100">
    <div class="logo-div">
        <img src="images/first_sch.png" alt="">
    </div>

    <div class="categories w-75">
        <div class=""></div>
        <a href="/"><button class="nav_btn w-100"><span class="hov"></span> HOME</button></a>
        <button class="nav_btn"><span class="hov"></span> ABOUT</button>
        <a href="register" class="w-100"> <button class="nav_btn w-100"><span class="hov"></span> ENROLL</button></a>

        <div class="menu-div">
            <button class="btn-text"><i class="fa-regular fa-compass"></i></button>
        </div>
    </div>
</nav>